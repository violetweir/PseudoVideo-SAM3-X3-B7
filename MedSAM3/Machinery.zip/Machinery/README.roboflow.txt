
Machinery - v2 2022-11-10 6:02pm
==============================

This dataset was exported via roboflow.com on November 10, 2022 at 10:02 AM GMT

Roboflow is an end-to-end computer vision platform that helps you
* collaborate with your team on computer vision projects
* collect & organize images
* understand unstructured image data
* annotate, and create datasets
* export, train, and deploy computer vision models
* use active learning to improve your dataset over time

It includes 153 images.
Bulldozer are annotated in PNG Masks For Semantic Segmentation format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 640x640 (Stretch)

No image augmentation techniques were applied.


